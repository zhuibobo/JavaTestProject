create proc sp_select_person
as
    select * from dbo.person
GO

