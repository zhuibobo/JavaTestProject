create procedure sp_insert_person_out_param
@id int,
@name varchar(50),
@sex varchar(10),
@age int,
@idcard varchar(50),
@brithday datetime,
@outidcard varchar(50) out,
@outname varchar(50) output
as     
   begin    
       insert into person(id,name,sex,age,idcard,brithday) values (@id,@name,@sex,@age,@idcard,@brithday);
       select @outidcard=idcard,@outname=name from person where id=@id
   end;
GO

