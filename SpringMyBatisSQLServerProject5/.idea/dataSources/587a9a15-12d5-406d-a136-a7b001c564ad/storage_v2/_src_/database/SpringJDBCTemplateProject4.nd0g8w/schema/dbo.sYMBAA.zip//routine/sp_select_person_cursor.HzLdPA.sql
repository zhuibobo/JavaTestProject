create proc sp_select_person_cursor
    @cur cursor varying output
as
    set @cur = cursor forward_only static for
    select * from person;
    open @cur;
GO

