create proc sp_select_person_2_result
as
    select * from dbo.person;
    select 'hellow' newc,* from dbo.person;
GO

