create procedure sp_insert_person_not_out
@id int,
@name varchar(50),
@sex varchar(10),
@age int,
@idcard varchar(50),
@brithday datetime
as     
   begin    
       insert into person(id,name,sex,age,idcard,brithday) values (@id,@name,@sex,@age,@idcard,@brithday);    
   end;
GO

