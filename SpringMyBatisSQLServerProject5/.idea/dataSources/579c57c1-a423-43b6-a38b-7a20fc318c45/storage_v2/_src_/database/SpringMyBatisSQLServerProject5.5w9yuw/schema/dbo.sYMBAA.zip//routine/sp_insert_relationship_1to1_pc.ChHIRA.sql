create procedure sp_insert_relationship_1to1_pc
    @id int,
    @name varchar(50),
    @cpuid varchar(50)
as
  begin
    insert into relationship_1to1_pc(id,name,cpu_id) values (@id,@name,@cpuid);
  end
GO

